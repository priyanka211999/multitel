import React from 'react'
import test from "./assets/test.png"
import "./staticcard.css"

function example() {
  return (
      <center>
    <div className='container'>
        <img src={test} class="img-fluid" alt="Responsive image"/>
        <button class="btn">we're Multitel</button>
  <div class="data">
  <h4 className='Data'>Experience new generation of Internet</h4>
  </div>
  <h5 class="sub">our Plan starts with $20</h5>

  <button class="btnn"><a>Get started</a></button>
 
</div>
    </center>
  )
}

export default example